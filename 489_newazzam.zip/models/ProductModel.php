<?php
class ProductModel {
    private $pdo;
    public function __construct($pdo) { $this->pdo = $pdo; }

    public function getAllProducts() {
        $stmt = $this->pdo->query("
            SELECT p.*, c.categoryName
            FROM Product p
            LEFT JOIN Category c ON p.categoryID = c.categoryID
        ");
        $rows = $stmt->fetchAll();
        foreach ($rows as &$row) {
            $pics = json_decode($row['pictures'], true) ?? [];
            $row['firstImage'] = $pics[0] ?? 'placeholder.jpg';
        }
        return $rows;
    }

    public function getProductByID($id) {
        $stmt = $this->pdo->prepare("
            SELECT p.*, c.categoryName
            FROM Product p
            LEFT JOIN Category c ON p.categoryID = c.categoryID
            WHERE p.productID = ?
        ");
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        if ($row) {
            $row['pictures'] = json_decode($row['pictures'], true) ?? [];
        }
        return $row;
    }
}
?>