<?php
require_once 'database.php';
require_once 'models/ProductModel.php';

if (!isset($_GET['id'])) {
    die("Product ID is required");
}

$productModel = new ProductModel($pdo);
$product = $productModel->getProductByID($_GET['id']);

if (!$product) {
    die("Product not found.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?= htmlspecialchars($product['productName']) ?></title>
<link rel="stylesheet" href="https://quickcart-gs.vercel.app/css/style.css">
<style>
.gallery{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:1rem}
.gallery img{width:250px;border-radius:8px;object-fit:contain}
</style>
</head>
<body>
<h1><?= htmlspecialchars($product['productName']) ?></h1>
<div class="gallery">
<?php foreach ($product['pictures'] as $pic): ?>
    <img src="<?= htmlspecialchars($pic) ?>" alt="">
<?php endforeach; ?>
</div>
<p><?= nl2br(htmlspecialchars($product['productDescription'])) ?></p>
<p><strong>Price: <?= number_format($product['price'],2) ?> BD</strong></p>
<p>Category: <?= htmlspecialchars($product['categoryName']) ?></p>

<form action="cart_add.php" method="post">
  <input type="hidden" name="productID" value="<?= $product['productID'] ?>">
  <button type="submit">Add to Cart</button>
</form>
</body>
</html>