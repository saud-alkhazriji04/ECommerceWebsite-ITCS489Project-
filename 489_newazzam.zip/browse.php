<?php
require_once 'database.php';
require_once 'models/ProductModel.php';

$productModel = new ProductModel($pdo);
$products = $productModel->getAllProducts();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>QuickCart – Browse</title>
<link rel="stylesheet" href="https://quickcart-gs.vercel.app/css/style.css">
<style>
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:1rem;margin:2rem auto;max-width:1200px}
.card{border:1px solid #eee;padding:10px;border-radius:8px;text-align:center;transition:box-shadow .2s}
.card:hover{box-shadow:0 2px 8px rgba(0,0,0,.15)}
.card img{object-fit:contain;height:150px;width:100%}
</style>
</head>
<body>
<h1 style="text-align:center">Products</h1>
<div class="grid">
<?php foreach ($products as $p): ?>
  <div class="card">
    <a href="product.php?id=<?= $p['productID'] ?>" style="text-decoration:none;color:inherit">
      <img src="<?= htmlspecialchars($p['firstImage']) ?>" alt="<?= htmlspecialchars($p['productName']) ?>">
      <h3><?= htmlspecialchars($p['productName']) ?></h3>
    </a>
    <p><strong><?= number_format($p['price'],2) ?> BD</strong></p>
  </div>
<?php endforeach; ?>
</div>
</body>
</html>